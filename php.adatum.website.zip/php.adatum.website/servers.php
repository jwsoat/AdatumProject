<!-- Place Everything Inside Main DIV -->
<div class="servers-container">
<?php
include "navbar.html";
?>
  <h1>Servers</h1>
  <div class="server-content-container">
    <div class="server-content-left">
  <p> Server: OS-Windows Server 2016 Standard.<br>
    2x HPE ProLiant DL360 Gen10 :Intel® Xeon® Scaleable 4114 2.20 GHz, 13.75M Cache.<br>
    Processor cache : 13.75 MB L3.<br>
    Processor Name : Intel® Xeon® Scalable 4114 .(10 core, 2.2 GHz, 85W).<br>
    Processor number : 1 processor.<br>
    Processor speed : 2.2 GHz.<br>
    Maximum memory : 768 GB, memory supported differs by processor selection.<br>
    Memory type : HPE DDR4 SmartMemory.<br>
    Memory, standard : 16 GB (1x 16 GB) RDIMM.<br>
    Included hard drives : None ship standard, 8SFF drives supported.<br>
    Security : Optional locking Bezel Kit, Intrusion Detection Kit, and HPE TPM 2.0.<br>
    <br>
    Windows Server 2016 Standard<br>
    Disaster Recovery - Automatic secure offsite data backup.<br>
    Increased application uptime through multi-site failover clustering.<br>
    Flexible and cost-effective data storage.<br>
    Combine on-premises servers with cloud on your terms.<br>
    Virtualize your applications to decrease costs and increase flexibility.<br>
  </p>
    </div>
    <div class="server-content-right">
<img style="border-radius: 2%;" src="https://cdn2.itpro.co.uk/sites/itpro/files/2018/12/hpe_proliant_dl325_gen10.jpg" alt="Smiley face" height="auto" width="100%">
    </div>
  </div>
</div>
<?php
include "footer.html";
?>