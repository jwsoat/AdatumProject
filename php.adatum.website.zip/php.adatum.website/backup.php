<div class="backup-container">
<?php
include "navbar.html";
?>
  <div class="backup-content-container">
    <div class="backup-content-left">
        <a href="/Assets/Docs/quote.zip">45 Drives Backup Server Quote</a>
        <iframe src="/Assets/Docs/quote.pdf" width="1800" height="1300" scrolling="no" ></iframe>

    </div>
    <div class="backup-content-right">

    </div>
  </div>

</div>
<?php
include "footer.html";
?>