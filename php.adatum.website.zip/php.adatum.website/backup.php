<div class="backup-container">
<?php
include "navbar.html";
?>
  <div class="backup-content-container">
    <div class="backup-content-left">

    </div>
    <div class="backup-content-right">

    </div>
  </div>
<a href="/Assets/Docs/quote.pdf">45 Drives Backup Server Quote</a>
</div>
<?php
include "footer.html";
?>