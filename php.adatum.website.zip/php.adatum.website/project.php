<div class="report-container">
<?php
include "navbar.html";
?>
<iframe src="https://docs.google.com/document/d/e/2PACX-1vTyM_H9qMoMdPgavCenQcKAPD43fSZV0L0jLe_8o9rMmWK2QB4fhuU34w2H10FMrK1l3KPkYsLrJlEV/pub?embedded=true" width="960" height="100vh"></iframe>
</div>
<?php
include "footer.html";
?>