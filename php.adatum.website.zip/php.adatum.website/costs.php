<div class="costs-container">
<?php
include "navbar.html";
?>
<h1>Costs</h1>

  <table class="table table-sm table-dark">
    <thead>
      <tr>
        <th scope="col">Quantity</th>
        <th scope="col">Product</th>
        <th scope="col">Cost NZD</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th>1</th>
        <td><a href="/Assets/Docs/quote.pdf">45 Drives Storinator Q30 Enhanced</a></td>
        <td>$18671.81</td>
      </tr>
      <tr>
        <th>2</th>
        <td>Windows Server 2016 Standard</td>
        <td>$1599.98</td>
      </tr>
      <tr>
        <th>2</th>
        <td>HPE ProLiant DL360 Gen10</td>
        <td>$11019.64</td>
      </tr>
      <tr>
        <th>1</th>
        <td>Ubuntu Server 18.04 LTS</td>
        <td>$0</td>
      </tr>
      <tr>
        <th>10</th>
        <td>Windows 10 Pro</td>
        <td>$3208.50</td>
      </tr>
      <tr>
        <th>16</th>
        <td>HPE 900GB Enterprise HDD</td>
        <td>$23374.44</td>
      </tr>
      <tr>
        <th>10</th>
        <td>Custom Built PCs</td>
        <td>$9798.40</td>
      </tr>
    </tbody>
  </table>
</div>
<?php
include "footer.html";
?>